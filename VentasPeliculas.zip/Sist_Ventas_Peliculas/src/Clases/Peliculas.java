/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author kaoz_
 */
public class Peliculas {
    private int idPelicula;
    private String nombrePelicula;
    private String formatoPelicula;
    private String categoriaPelicula;

    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getNombrePelicula() {
        return nombrePelicula;
    }

    public void setNombrePelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;
    }

    public String getFormatoPelicula() {
        return formatoPelicula;
    }

    public void setFormatoPelicula(String formatoPelicula) {
        this.formatoPelicula = formatoPelicula;
    }

    public String getCategoriaPelicula() {
        return categoriaPelicula;
    }

    public void setCategoriaPelicula(String categoriaPelicula) {
        this.categoriaPelicula = categoriaPelicula;
    }

    public Peliculas(int idPelicula, String nombrePelicula, String formatoPelicula, String categoriaPelicula) {
        this.idPelicula = idPelicula;
        this.nombrePelicula = nombrePelicula;
        this.formatoPelicula = formatoPelicula;
        this.categoriaPelicula = categoriaPelicula;
    }

    public Peliculas() {
    }
}
