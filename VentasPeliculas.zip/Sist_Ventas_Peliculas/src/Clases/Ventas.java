/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author kaoz_
 */
public class Ventas {
    private int idVenta;
    private String cliente;
    private String producto;
    private int precioNeto;
    private int precioTotal;

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getPrecioNeto() {
        return precioNeto;
    }

    public void setPrecioNeto(int precioNeto) {
        this.precioNeto = precioNeto;
    }

    public int getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(int precioTotal) {
        this.precioTotal = precioTotal;
    }

    public Ventas(int idVenta, String cliente, String producto, int precioNeto, int precioTotal) {
        this.idVenta = idVenta;
        this.cliente = cliente;
        this.producto = producto;
        this.precioNeto = precioNeto;
        this.precioTotal = precioTotal;
    }

    public Ventas() {
    }
}
