/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author kaoz_
 */
import Clases.Ventas;
import java.sql.*;
import java.util.ArrayList;
import sist_ventas_peliculas.Conexion.Conexion;

public class VentasControlador {
    public VentasControlador() {
    }

    
    public Ventas getVenta(int idVenta) {
        Ventas venta = null;
        String sql = "SELECT * FROM ventas WHERE idVenta = ?";
        try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                venta = new Ventas(
                        rs.getInt("idVenta"),
                        rs.getString("cliente"),
                        rs.getString("producto"),
                        rs.getInt("precioNeto"),
                        rs.getInt("precioTotal")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error al buscar venta: " + ex.getMessage());
        }
        return venta;
    }

    
    public ArrayList<Ventas> listarVentas() {
    ArrayList<Ventas> listaVentas = new ArrayList<>();
    String sql = "SELECT * FROM VENTAS";
    

    try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Ventas venta = new Ventas();
            venta.setIdVenta(rs.getInt("idVenta"));
            venta.setCliente(rs.getString("cliente"));
            venta.setProducto(rs.getString("producto"));
            venta.setPrecioNeto(rs.getInt("precioNeto"));
            venta.setPrecioTotal(rs.getInt("precioTotal"));
            listaVentas.add(venta);
        }
    } catch (SQLException ex) {
        System.out.println("Error al listar ventas: " + ex.getMessage());
    }

    return listaVentas;
}



    
    public void ingresarVenta(Ventas venta) {
        String sql = "INSERT INTO ventas (cliente, producto, precioNeto, precioTotal) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
            ps.setString(1, venta.getCliente());
            ps.setString(2, venta.getProducto());
            ps.setInt(3, venta.getPrecioNeto());
            ps.setInt(4, venta.getPrecioTotal());

            ps.executeUpdate();
            System.out.println("Venta ingresada exitosamente.");
        } catch (SQLException ex) {
            System.out.println("Error al ingresar venta: " + ex.getMessage());
        }
    }

    
    public boolean modificarVenta(Ventas venta) {
    try {
        Connection conn = Conexion.getConnection();
        String sql = "UPDATE ventas SET cliente = ?, producto = ?, precioNeto = ?, precioTotal = ? WHERE idVenta = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, venta.getCliente());
        ps.setString(2, venta.getProducto());
        ps.setInt(3, venta.getPrecioNeto());
        ps.setInt(4, venta.getPrecioTotal());
        ps.setInt(5, venta.getIdVenta());
        int filasActualizadas = ps.executeUpdate();
        return filasActualizadas > 0;
    } catch (SQLException e) {
        System.out.println("Error al modificar la venta: " + e.getMessage());
        return false;
    }
}

    
    public Boolean eliminarVenta(int idVenta) {
        String sql = "DELETE FROM ventas WHERE idVenta = ?";
        try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idVenta);

            int rowsDeleted = ps.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Venta eliminada exitosamente.");
            } else {
                System.out.println("No se encontró una venta con ese ID.");
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar venta: " + ex.getMessage());
        }
        return true;
    }
    
    
}

