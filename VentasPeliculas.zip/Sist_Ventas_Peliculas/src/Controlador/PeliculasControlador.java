/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Clases.Peliculas;
import java.sql.*;
import java.util.ArrayList;
import sist_ventas_peliculas.Conexion.Conexion;
/**
 *
 * @author kaoz_
 */
public class PeliculasControlador {
    public PeliculasControlador() {
    }

    public Peliculas getPelicula(int idPelicula) {
        Peliculas pelicula = null;
        String sql = "SELECT * FROM peliculas WHERE idPelicula = ?";
        try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idPelicula);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pelicula = new Peliculas(
                        rs.getInt("idPelicula"),
                        rs.getString("nomPelicula"),
                        rs.getString("formatoPelicula"),
                        rs.getString("categoriaPelicula")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error al buscar película: " + ex.getMessage());
        }
        return pelicula;
    }

 
    public ArrayList<Peliculas> listarPeliculas() {
    ArrayList<Peliculas> listaPeliculas = new ArrayList<>();
    String sql = "SELECT idPelicula, nomPelicula, formatoPelicula, categoriaPelicula FROM peliculas";

    try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        // Recorrer los resultados y crear objetos Peliculas
        while (rs.next()) {
            Peliculas pelicula = new Peliculas();
            pelicula.setIdPelicula(rs.getInt("idPelicula"));
            pelicula.setNombrePelicula(rs.getString("nomPelicula"));
            pelicula.setFormatoPelicula(rs.getString("formatoPelicula"));
            pelicula.setCategoriaPelicula(rs.getString("categoriaPelicula"));

            listaPeliculas.add(pelicula);
        }
    } catch (SQLException ex) {
        System.out.println("Error al listar películas: " + ex.getMessage());
    }

    return listaPeliculas;
}


 
    public boolean ingresarPelicula(Peliculas pelicula) {
        String sql = "INSERT INTO peliculas (nomPelicula, formatoPelicula, categoriaPelicula) VALUES (?, ?, ?)";
        try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
            ps.setString(1, pelicula.getNombrePelicula());
            ps.setString(2, pelicula.getFormatoPelicula());
            ps.setString(3, pelicula.getCategoriaPelicula());

            ps.executeUpdate();
            System.out.println("Película ingresada exitosamente.");
        } catch (SQLException ex) {
            System.out.println("Error al ingresar película: " + ex.getMessage());
        }
        return true;
    }

    // Método para modificar una película
    public boolean modificarPelicula(Peliculas pelicula) {
    String sql = "UPDATE peliculas SET nomPelicula = ?, formatoPelicula = ?, categoriaPelicula = ? WHERE idPelicula = ?";
    try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
        ps.setString(1, pelicula.getNombrePelicula());
        ps.setString(2, pelicula.getFormatoPelicula());
        ps.setString(3, pelicula.getCategoriaPelicula());
        ps.setInt(4, pelicula.getIdPelicula());

        int rowsUpdated = ps.executeUpdate();
        return rowsUpdated > 0; // Retorna true si se actualizó al menos una fila, false en caso contrario.
    } catch (SQLException ex) {
        System.out.println("Error al modificar película: " + ex.getMessage());
        return false; // Retorna false si ocurre un error.
    }
}

    public Peliculas buscarPeliculasPorId(int idPelicula) {
    String sql = "SELECT idPelicula, nomPelicula, formatoPelicula, categoriaPelicula FROM peliculas WHERE idPelicula = ?";
    try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
        ps.setInt(1, idPelicula);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                // Crear un objeto Peliculas con los datos obtenidos
                return new Peliculas(
                    rs.getInt("idPelicula"),
                    rs.getString("nomPelicula"),
                    rs.getString("formatoPelicula"),
                    rs.getString("categoriaPelicula")
                );
            }
        }
    } catch (SQLException ex) {
        System.out.println("Error al buscar película: " + ex.getMessage());
    }
    return null; // Retorna null si no se encontró la película o si ocurrió un error
}


 
    public boolean eliminarPelicula(int idPelicula) {
    String sql = "DELETE FROM peliculas WHERE idPelicula = ?";
    try (PreparedStatement ps = Conexion.getConnection().prepareStatement(sql)) {
        ps.setInt(1, idPelicula);

        // Ejecutar la eliminación
        int rowsDeleted = ps.executeUpdate();

        // Verificar si se eliminó alguna fila
        return rowsDeleted > 0;
    } catch (SQLException ex) {
        System.out.println("Error al eliminar película: " + ex.getMessage());
    }
    return false; // Retorna false si no se eliminó nada o ocurrió un error
}

}

    
