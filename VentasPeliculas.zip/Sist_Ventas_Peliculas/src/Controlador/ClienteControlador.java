/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Clases.Cliente;
import java.sql.*;
import java.util.ArrayList;
import sist_ventas_peliculas.Conexion.Conexion;
/**
 *
 * @author kaoz_
 */
public class ClienteControlador {
    private Statement st;

    public ClienteControlador() {
    }
    public Cliente BuscarCliente(String rut){
        Cliente cli = null;
        String sql = "SELECT * FROM cliente where rut = '"+rut+"';";
        try(Statement st = Conexion.getConnection().createStatement()){
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                cli = new Cliente(
                        rs.getString("Rut"),
                        rs.getString("nombre"),
                        rs.getString("apPaterno"),
                        rs.getString("apMaterno"),
                        rs.getInt("telefono"),
                        rs.getString("correo"),
                        rs.getString("direccion")
                );
            }
        }catch(SQLException ex){
            System.out.println("Error al encontrar RUT buscado: "+ex.getMessage());
        }
        return cli;
    }
    
    public ArrayList<Cliente> clientes(){
        String sql = "SELECT * FROM cliente";
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        try(Statement st = Conexion.getConnection().createStatement()){
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                clientes.add(new Cliente(
                        rs.getString("Rut"),
                        rs.getString("nombre"),
                        rs.getString("apPaterno"),
                        rs.getString("apMaterno"),
                        rs.getInt("telefono"),
                        rs.getString("correo"),
                        rs.getString("direccion")
                ));
            }
        }catch(SQLException ex){
            System.out.println("Error en listarClientes "+ex.getMessage());
        }
        return clientes;
    }
    
    public void IngresarCliente(Cliente cli) {
    String sql = "INSERT INTO Cliente (Rut, nombre, apPaterno, apMaterno, telefono, correo, direccion) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?)";
    try {
        
        PreparedStatement ps = Conexion.getConnection().prepareStatement(sql);
        ps.setString(1, cli.getRut());         // Rut
        ps.setString(2, cli.getNombre());      // Nombre
        ps.setString(3, cli.getApPaterno());   // Apellido Paterno
        ps.setString(4, cli.getApMaterno());   // Apellido Materno
        ps.setInt(5, cli.getTelefono());    // Teléfono
        ps.setString(6, cli.getCorreo());      // Correo
        ps.setString(7, cli.getDireccion());   // Dirección
        
        
        ps.executeUpdate();
        System.out.println("Cliente ingresado exitosamente.");
    } catch (SQLException ex) {
        System.out.println("Error al ingresar Cliente: " + ex.getMessage());
    }
}

    
    public void ModificarCliente(Cliente cli) {
    String sql = "UPDATE Cliente SET nombre = ?, apPaterno = ?, apMaterno = ?, telefono = ?, correo = ?, direccion = ? " +
                 "WHERE Rut = ?";
    try {
        
        PreparedStatement ps = Conexion.getConnection().prepareStatement(sql);
        ps.setString(1, cli.getNombre());      // Nombre
        ps.setString(2, cli.getApPaterno());   // Apellido Paterno
        ps.setString(3, cli.getApMaterno());   // Apellido Materno
        ps.setInt(4, cli.getTelefono());    // Teléfono
        ps.setString(5, cli.getCorreo());      // Correo
        ps.setString(6, cli.getDireccion());   // Dirección
        ps.setString(7, cli.getRut());         // Rut (Condición de búsqueda)

        
        int rowsUpdated = ps.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Cliente actualizado exitosamente.");
        } else {
            System.out.println("No se encontró un cliente con ese Rut.");
        }
    } catch (SQLException ex) {
        System.out.println("Error al modificar Cliente: " + ex.getMessage());
    }
}

    
    public boolean EliminarCliente(String rut) {
    String sql = "DELETE FROM Cliente WHERE Rut = ?";
    try {
        PreparedStatement ps = Conexion.getConnection().prepareStatement(sql);
        ps.setString(1, rut);

        int rowsDeleted = ps.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("Cliente eliminado exitosamente.");
            return true;  // Cliente eliminado exitosamente
        } else {
            System.out.println("No se encontró un cliente con ese Rut.");
            return false; // No se encontró el cliente
        }
    } catch (SQLException ex) {
        System.out.println("Error al eliminar Cliente: " + ex.getMessage());
        return false; // En caso de error, retornar false
    }
}


    
}
